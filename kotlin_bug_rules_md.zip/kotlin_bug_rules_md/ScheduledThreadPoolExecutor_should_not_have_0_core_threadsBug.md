---
title: ""ScheduledThreadPoolExecutor" should not have 0 core threads"
---

## "ScheduledThreadPoolExecutor" should not have 0 core threads

### Examples
```kotlin
java.util.concurrent.ScheduledThreadPoolExecutor
corePoolSize
corePoolSize
corePoolSize
fun do() {

    val stpe1 = ScheduledThreadPoolExecutor(0) // Noncompliant

    val stpe2 = ScheduledThreadPoolExecutor(POOL_SIZE)
    stpe2.corePoolSize = 0 // Noncompliant

    ...
```
