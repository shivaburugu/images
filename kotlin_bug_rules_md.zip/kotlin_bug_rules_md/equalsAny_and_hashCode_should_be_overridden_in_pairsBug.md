---
title: ""equals(Any?)" and "hashCode()" should be overridden in pairs"
---

## "equals(Any?)" and "hashCode()" should be overridden in pairs

### Examples
```kotlin
equals(Any?)
hashCode()
hashCode
equals
equals
hashCode
class MyClass {    // Noncompliant - should also override "hashCode()"

  override fun equals(other: Any?): Boolean {
    /* ... */
  }

}
class MyClass {    // Compliant

  override fun equals(other: Any?): Boolean {
    /* ... */
  }

  override fun hashCode(): Int {
    /* ... */
  }

}
```
