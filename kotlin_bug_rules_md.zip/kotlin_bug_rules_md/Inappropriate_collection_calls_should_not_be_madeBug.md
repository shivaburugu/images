---
title: "Inappropriate collection calls should not be made"
---

## Inappropriate collection calls should not be made

### Examples
```kotlin
Iterable.contains
false
null
MutableCollection.remove
MutableCollection.removeAll
MutableCollection.retainAll
Array.contains
Array.indexOf
Array.lastIndexOf
Collection.containsAll
Iterable.contains
Iterable.indexOf
Iterable.lastIndexOf
List.indexOf
List.lastIndexOf
Map.contains
Map.containsKey
Map.containsValue
Map.get
MutableMap.remove
fun main(args: Array<String>) {
    val map: MutableMap<Int, Any> = mutableMapOf()
    map.remove<Any, Any>("42") // Noncompliant; will return 'null' for sure because 'map' is handling only Integer keys

    // ...
    val list: MutableList<String> = mutableListOf()
    val integer = Integer.valueOf(1)
    if (list.contains<Any>(integer)) { // Noncompliant; always false.
        list.remove<Any>(integer) // Noncompliant; list.add(integer) doesn't compile, so this will always return 'false'
    }
}
fun main(args: Array<String>) {
    val map: MutableMap<Int, Any> = mutableMapOf()
    map.remove(42)

    // ...
    val list: MutableList<String> = mutableListOf()
    val str = ""
    if (list.contains(str)) {
        list.remove(str)
    }
}
```
