---
title: "Flow intermediate operation results should not be left unused"
---

## Flow intermediate operation results should not be left unused

### Examples
```kotlin
Flow
Stream
Sequence
Flow
Stream
Sequence
Flow
Flow
suspend fun main() {
    val flow = flow {
        emit(1)
        emit(2)
        emit(3)
    }

    flow.take(2) // Noncompliant, the result of this operation is never used
}
suspend fun main() {
    val flow = flow {
        emit(1)
        emit(2)
        emit(3)
    }

    flow.take(2).collect { println(it) } // Compliant, collect is a terminal operation
}
```
