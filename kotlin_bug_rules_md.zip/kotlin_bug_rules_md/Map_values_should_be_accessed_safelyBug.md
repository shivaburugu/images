---
title: ""Map" values should be accessed safely"
---

## "Map" values should be accessed safely

### Examples
```kotlin
Map
null
!!
null
NullPointerException
!!
Map
!!
Map
NullPointerException
```
