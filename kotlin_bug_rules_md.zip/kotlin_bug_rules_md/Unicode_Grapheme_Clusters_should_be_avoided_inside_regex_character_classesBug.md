---
title: "Unicode Grapheme Clusters should be avoided inside regex character classes"
---

## Unicode Grapheme Clusters should be avoided inside regex character classes

### Examples
```kotlin
c̈
'c'
'\u{0308}'
[c̈]
[c\u{0308}]
'c'
"cc̈d̈d".replace(Regex("[c̈d̈]"), "X") // Noncompliant, print "XXXXXX" instead of expected "cXXd".
"cc̈d̈d".replace(Regex("c̈|d̈"), "X") // print "cXXd"
```
