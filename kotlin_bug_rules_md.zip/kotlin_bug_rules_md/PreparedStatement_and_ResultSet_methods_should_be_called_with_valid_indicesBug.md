---
title: ""PreparedStatement" and "ResultSet" methods should be called with valid indices"
---

## "PreparedStatement" and "ResultSet" methods should be called with valid indices

### Examples
```kotlin
PreparedStatement
ResultSet
Statement
ResultSet
PreparedStatement
ResultSet
PreparedStatement
ResultSet
IndexOutOfBoundsException
get
PreparedStatement
set
ResultSet
```
