---
title: "Repeated patterns in regular expressions should not match the empty string"
---

## Repeated patterns in regular expressions should not match the empty string

### Examples
```kotlin
"(?:)*"      // same as the empty regex, the '*' accomplishes nothing
"(?:|x)*"    // same as the empty regex, the alternative has no effect
"(?:x|)*"    // same as 'x*', the empty alternative has no effect
"(?:x*|y*)*" // same as 'x*', the first alternative would always match, y* is never tried
"(?:x?)*"    // same as 'x*'
"(?:x?)+"    // same as 'x*'
"x*"
```
