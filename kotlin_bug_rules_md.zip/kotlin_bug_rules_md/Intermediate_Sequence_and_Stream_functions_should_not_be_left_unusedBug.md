---
title: "Intermediate Sequence and Stream functions should not be left unused"
---

## Intermediate Sequence and Stream functions should not be left unused

### Examples
```kotlin
val sequence = sequenceOf("Hello", " ", "World")
var totalLength = 0
sequence.map { totalLength += it.length } // Noncompliant, do nothing, "map" is not a terminal operation
// here totalLength == 0
val stream = listOf("Hello", " ", "World").stream()
stream.filter { it.isNotBlank() }  // Noncompliant, do nothing, "filter" is not a terminal operation
// the following "forEach" throws an exception, only one method can operate on a stream instance
// here "filter" has already operated on it.
stream.forEach { println(it) }
val sequence = listOf("Hello", " ", "World").asSequence()
var totalLength = sequence.map { it.length }.sum() // Compliant, the sequence ends with the terminal operation "sum"
// here totalLength == 11
listOf("Hello", " ", "World").stream()
    .filter { it.isNotBlank() }
    .forEach { println(it) } // Compliant, the stream ends with the terminal operation "forEach"
```
