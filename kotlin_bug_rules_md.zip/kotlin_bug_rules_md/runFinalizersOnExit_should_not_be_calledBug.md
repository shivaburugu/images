---
title: ""runFinalizersOnExit" should not be called"
---

## "runFinalizersOnExit" should not be called

### Examples
```kotlin
runFinalizersOnExit
fun main() {
  System.runFinalizersOnExit(true)  // Noncompliant
}
fun main() {
    Runtime.getRuntime().addShutdownHook(object : Thread() {
        override fun run() {
            doSomething()
        }
    })
}
```
