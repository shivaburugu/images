---
title: ""equals(other: Any?)" should test the argument's type"
---

## "equals(other: Any?)" should test the argument's type

### Examples
```kotlin
Any#equals(other: Any?)
other
Any?
null
Any#equals(other: Any?)
false
other
is
javaClass
override fun equals(other: Any?): Boolean {
  // ...
  if (other?.javaClass != this.javaClass) {
    return false
  }
  // ...
}
equals
other
ClassCastException
class MyClass {
  override fun equals(other: Any?): Boolean {
    val that = other as MyClass // may throw a ClassCastException
    // ...
  }
  // ...
}
other
```
