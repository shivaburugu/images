---
title: "Related "if/else if" statements should not have the same condition"
---

## Related "if/else if" statements should not have the same condition

### Examples
```kotlin
if
else if
true
```
