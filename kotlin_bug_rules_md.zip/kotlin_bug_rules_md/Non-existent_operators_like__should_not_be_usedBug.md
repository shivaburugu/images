---
title: "Non-existent operators like "=+" should not be used"
---

## Non-existent operators like "=+" should not be used

### Examples
```kotlin
=+
=-
=!
+=
-=
!=
var target = -5
val num = 3

target =- num // Noncompliant: target = -3. Is that the expected behavior?
target =+ num // Noncompliant: target = 3
=+
=-
=!
var target = -5
val num = 3

target -= num // target = -8
var target = -5
val num = 3

target = -num // target = -3
```
