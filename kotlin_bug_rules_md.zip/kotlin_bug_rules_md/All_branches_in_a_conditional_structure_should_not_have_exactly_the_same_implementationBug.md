---
title: "All branches in a conditional structure should not have exactly the same implementation"
---

## All branches in a conditional structure should not have exactly the same implementation

### Examples
```kotlin
when
if
if (b == 0) {  // Noncompliant
     doOneMoreThing()
} else {
     doOneMoreThing()
}

when (i) {  // Noncompliant
    1 -> doSomething()
    2 -> doSomething()
    3 -> doSomething()
    else -> doSomething()
}
when
if
if
else
when
else
if (b == 0) {
    doOneMoreThing()
} else if (b == 1) {
    doOneMoreThing()
}
```
