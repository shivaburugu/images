---
title: "Collections should not be passed as arguments to their own methods"
---

## Collections should not be passed as arguments to their own methods

