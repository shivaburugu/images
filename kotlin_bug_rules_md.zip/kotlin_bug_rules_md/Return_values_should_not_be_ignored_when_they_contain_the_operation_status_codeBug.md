---
title: "Return values should not be ignored when they contain the operation status code"
---

## Return values should not be ignored when they contain the operation status code

### Examples
```kotlin
java.io.File
mkdirs
Iterator.hasNext()
Enumeration.hasMoreElements()
Lock.tryLock()
Condition.await*
CountDownLatch.await(long, TimeUnit)
Semaphore.tryAcquire
BlockingQueue
offer
remove
fun doSomething(file: File, lock: Lock) {
    file.delete() // Noncompliant
    // ...
    lock.tryLock() // Noncompliant
}
fun doSomething(file: File, lock: Lock) {
    if (!file.delete()) {
        // file delete failed; take appropriate action
    }
    if (!lock.tryLock()) {
        // lock failed; take appropriate action
    }
}
```
