---
title: "Collection and array sizes comparisons should make sense"
---

## Collection and array sizes comparisons should make sense

### Examples
```kotlin
true
if (myList.size >= 0) {...} // Noncompliant: always true

boolean result = myArray.size >= 0; // Noncompliant: always true
false
if (myList.size < 0) {...} // Noncompliant: always false
```
