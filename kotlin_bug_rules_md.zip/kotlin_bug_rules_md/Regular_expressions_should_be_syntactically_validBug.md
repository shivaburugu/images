---
title: "Regular expressions should be syntactically valid"
---

## Regular expressions should be syntactically valid

### Examples
```kotlin
RegexOption.LITERAL
Regex("([")
"([".toRegex()
Regex("\\(\\[")
Regex("""\(\[""")
"\\(\\[".toRegex()
"""\(\[""".toRegex()

Regex("([", RegexOption.LITERAL)
"([".toRegex(RegexOption.LITERAL)
```
