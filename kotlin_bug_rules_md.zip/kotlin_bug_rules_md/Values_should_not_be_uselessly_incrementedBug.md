---
title: "Values should not be uselessly incremented"
---

## Values should not be uselessly incremented

### Examples
```kotlin
fun pickNumber() : Int {
  var i = 0
  var j = 0

  i = i++ // Noncompliant; i is still zero

  return j++ // Noncompliant; 0 returned
}
fun pickNumber() : Int {
  var i = 0
  var j = 0

  i++
  return ++j
}
```
