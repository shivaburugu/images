---
title: "All code should be reachable"
---

## All code should be reachable

### Examples
```kotlin
return
break
continue
fun foo(a: Int): Int {
  var i = 10;
  return a + i;       // Noncompliant
  i++;                // dead code
}
fun foo(a: Int): Int {
  var i = 10;
  return a + i;
}
```
