---
title: "Variables should not be self-assigned"
---

## Variables should not be self-assigned

### Examples
```kotlin
fun doSomething() {
    var name = ""
    // ...
    name = name
}
fun doSomething() {
    var name = ""
    // ...
    this.name = name
}
```
