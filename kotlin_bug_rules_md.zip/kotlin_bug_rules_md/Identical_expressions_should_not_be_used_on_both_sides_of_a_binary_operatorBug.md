---
title: "Identical expressions should not be used on both sides of a binary operator"
---

## Identical expressions should not be used on both sides of a binary operator

### Examples
```kotlin
*
+
=
```
