---
title: "Alternatives in regular expressions should be grouped when used with anchors"
---

## Alternatives in regular expressions should be grouped when used with anchors

### Examples
```kotlin
^
$
\A
\Z
\z
|
^alt1|alt2|alt3$
alt1
alt3
alt2
^a|b|c$
^(?:a|b|c)$
^a$|^b$|^c$
a
c
(?:^a)|b|(?:c$)
```
