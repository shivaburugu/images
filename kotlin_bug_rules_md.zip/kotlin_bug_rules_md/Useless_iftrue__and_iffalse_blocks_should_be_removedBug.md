---
title: "Useless "if(true) {...}" and "if(false){...}" blocks should be removed"
---

## Useless "if(true) {...}" and "if(false){...}" blocks should be removed

### Examples
```kotlin
if
if
if
if (true) {
  doSomething()
}
...
if (false) {
  doSomethingElse()
}
doSomething()
...
```
